<?php

namespace App\Filament\Staff\Resources\ContractsResource\Pages;

use App\Filament\Staff\Resources\ContractsResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateContracts extends CreateRecord
{
    protected static string $resource = ContractsResource::class;
}
