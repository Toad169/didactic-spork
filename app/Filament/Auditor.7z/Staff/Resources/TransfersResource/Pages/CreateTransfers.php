<?php

namespace App\Filament\Staff\Resources\TransfersResource\Pages;

use App\Filament\Staff\Resources\TransfersResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTransfers extends CreateRecord
{
    protected static string $resource = TransfersResource::class;
}
