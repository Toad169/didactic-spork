<?php

namespace App\Filament\Staff\Resources\SavingsResource\Pages;

use App\Filament\Staff\Resources\SavingsResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSavings extends CreateRecord
{
    protected static string $resource = SavingsResource::class;
}
