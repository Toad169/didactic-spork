<?php

namespace App\Filament\Auditor\Resources;

use App\Filament\Auditor\Resources\AccountsResource\Pages;
use App\Filament\Auditor\Resources\AccountsResource\RelationManagers;
use App\Models\Accounts;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Forms\Components\TextInput;
use Filament\Tables\Columns\TextColumn;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class AccountsResource extends Resource
{
    protected static ?string $model = Accounts::class;

    protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                //
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                //
                TextColumn::make('user_id')
                    ->sortable()
                    ->searchable()
                    ->label('User ID'),
                TextColumn::make('account_number')
                    ->sortable()
                    ->searchable()
                    ->label('Account Number'),
                TextColumn::make('account_type')
                    ->sortable()
                    ->searchable()
                    ->label('Account Type'),
                TextColumn::make('balance')
                    ->sortable()
                    ->searchable()
                    ->label('Balance'),
                TextColumn::make('status')
                    ->sortable()
                    ->searchable()
                    ->label('Account Status'),
                    
                // TextColumn::make('created_at')
                //     ->dateTime()
                //     ->sortable()
                //     ->searchable()
                //     ->label('Created At'),
                // TextColumn::make('updated_at')
                //     ->dateTime()
                //     ->sortable()
                //     ->searchable()
                //     ->label('Updated At'),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListAccounts::route('/'),
            'create' => Pages\CreateAccounts::route('/create'),
            'edit' => Pages\EditAccounts::route('/{record}/edit'),
        ];
    }
}
