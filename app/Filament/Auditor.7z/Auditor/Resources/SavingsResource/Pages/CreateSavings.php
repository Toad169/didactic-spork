<?php

namespace App\Filament\Auditor\Resources\SavingsResource\Pages;

use App\Filament\Auditor\Resources\SavingsResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSavings extends CreateRecord
{
    protected static string $resource = SavingsResource::class;
}
