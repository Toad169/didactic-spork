<?php

namespace App\Livewire;

use App\Models\Savings;

use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class SavingsStat extends BaseWidget
{
    protected function getStats(): array
    {
        return [
            //
        ];
    }
}
