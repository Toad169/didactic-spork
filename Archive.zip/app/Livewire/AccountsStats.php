<?php

namespace App\Livewire;

use App\Models\Accounts;

use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class AccountsStats extends BaseWidget
{
    protected function getStats(): array
    {
        return [
            //
        ];
    }
}
