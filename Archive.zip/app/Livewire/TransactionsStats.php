<?php

namespace App\Livewire;

use App\Models\Transactions;

use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class TransactionsStats extends BaseWidget
{
    protected function getStats(): array
    {
        return [
            //
        ];
    }
}
