<?php

namespace App\Livewire;

use App\Models\Goals;

use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class GoalsStats extends BaseWidget
{
    protected function getStats(): array
    {
        return [
            //
        ];
    }
}
