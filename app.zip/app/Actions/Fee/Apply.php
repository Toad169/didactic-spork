<?php

namespace App\Actions\Fee;

use App\Models\Fee;

class Apply
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }

    public function execute(array $data): Fee {}
}
