<?php

namespace App\Actions\Zakat;

use App\Models\ZakatCalculation as Zakat;

class Calculate
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }

    public function execute(array $data): Zakat {}
}
