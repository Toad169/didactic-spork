<?php

namespace App\Actions\Profit;

use App\Models\ProfitSharing as Profit;

class Distribute
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }

    public function execute(array $data): Profit {}
}
