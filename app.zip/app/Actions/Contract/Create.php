<?php

namespace App\Actions\Contract;

use App\Models\Contract;

class Create
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }

    public function execute(array $data): Contract {}
}
