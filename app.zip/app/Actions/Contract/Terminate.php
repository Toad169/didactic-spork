<?php

namespace App\Actions\Contract;

use App\Models\Contract;

class Terminate
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }

    public function execute(array $data): Contract {}
}
