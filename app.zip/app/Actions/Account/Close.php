<?php

namespace App\Actions\Account;

use App\Models\Account;

class Close
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }

    public function execute(array $data): Account {}
}
