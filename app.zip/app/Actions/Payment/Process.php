<?php

namespace App\Actions\Payment;

use App\Models\Payment;

class Process
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }

    public function execute(array $data): Payment
    {

    }
}
