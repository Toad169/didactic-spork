<?php

namespace App\Actions\User;

use App\Models\User;
use App\Services\User as UserService;

class Update
{
    /**
     * Create a new class instance.
     */
    public function __construct(protected UserService $userService)
    {
        //
    }

    public function execute(int $userId, array $data): User
    {
        $user = User::findOrFail($userId);
        return $this->userService->updateUser($user, $data);
    }
}
