<?php

namespace App\Actions\User;

use App\Models\User;
use App\Services\User as UserService;

class Create
{
    /**
     * Create a new class instance.
     */
    public function __construct(protected UserService $userService)
    {
        //
    }

    public function execute(array $data): User
    {
        return $this->userService->createUser($data);
    }
}
