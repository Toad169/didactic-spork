<?php

namespace App\Actions\User;

use App\Models\User;
use App\Services\User as UserService;

class Delete
{
    /**
     * Create a new class instance.
     */
    public function __construct(protected UserService $userService)
    {
        //
    }

    public function execute(array $data): ?User
    {
        $user = User::find($data['id'] ?? null);

        if ($user) {
            $this->userService->deleteUser($user);
            return $user;
        }

        return null;
    }
}
