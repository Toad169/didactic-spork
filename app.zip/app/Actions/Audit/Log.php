<?php

namespace App\Actions\Audit;

use App\Models\AuditLogs as Audit;

class Log
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }

    public function execute(array $data): Audit {}
}
