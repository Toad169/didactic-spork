<?php

namespace App\Actions\Transaction;

use App\Models\Transaction;

class Cancel
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }

    public function execute(array $data): Transaction {}
}
