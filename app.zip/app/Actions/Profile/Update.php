<?php

namespace App\Actions\Profile;

use App\Models\Profile;

class Update
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }

    public function execute(array $data): Profile {}
}
