<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProfitSharing extends Model
{
    //
    use HasFactory;

    protected $fillable = [
        'profit_amount',
        'distributed_at',
    ];

    protected $guarded = [
        'user_id',
        'account_id',
        'contract_id',
    ];

    protected $hidden = [
        'user_id',
        'account_id',
        'contract_id',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function account()
    {
        return $this->belongsTo(Account::class);
    }

    public function contract()
    {
        return $this->belongsTo(Contract::class);
    }
}
