<?php

namespace App\Services;

use App\Models\AuditLog as Audit;

class AuditLog
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
