<?php

namespace App\Services;

use App\Models\User as UserModel;
use App\Models\Profile;
use Illuminate\Support\Facades\Hash;

class User
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }

    public function createUser(array $data): UserModel
    {
        return UserModel::create([
            'name'         => $data['name'],
            'email'        => $data['email'],
            'phone_number' => $data['phone_number'] ?? null,
            'password'     => Hash::make($data['password']),
            'role'         => $data['role'] ?? UserModel::ROLE_USER,
        ]);
    }

    public function updateUser(UserModel $user, array $data): UserModel
    {
        $user->update($data);
        return $user;
    }

    public function deleteUser(UserModel $user): void
    {
        $user->delete();
    }

}
