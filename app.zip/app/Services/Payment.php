<?php

namespace App\Services;

use App\Models\Payment as PaymentModel;

class Payment
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
