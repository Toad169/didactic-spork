<?php

namespace App\Services;

use App\Models\Fee as FeeModel;

class Fee
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
