<?php

namespace App\Services;

use App\Models\Transaction as TransactionModel;

class Transaction
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
