<?php

namespace App\Services;

use App\Models\Account as AccountModel;

class Account
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
