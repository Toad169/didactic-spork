<?php

namespace App\Services;

use App\Models\Contract as ContractModel;

class Contract
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
