<?php

namespace App\Filament\Staff\Pages;

use Filament\Pages\Page;

class Savings extends Page
{
    protected static ?string $navigationIcon = 'heroicon-o-document-text';

    protected static string $view = 'filament.staff.pages.savings';
}
