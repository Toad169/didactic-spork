<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ZakatCalculationController extends Controller
{
    //
    public function index() {}
    public function calculate(Request $request) {}
}
