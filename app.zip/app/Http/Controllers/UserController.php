<?php

namespace App\Http\Controllers;

use App\Actions\User\Create;
use App\Actions\User\Update;
use App\Actions\User\Delete;

use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\View\View;

class UserController extends Controller
{
    //
    public function index() {}
    public function show($id) {}
    public function store(Request $request) {}
    public function update(Request $request, $id) {}
    public function destroy($id) {}
}
