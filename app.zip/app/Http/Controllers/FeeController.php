<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FeeController extends Controller
{
    //
    public function index() {}
    public function store(Request $request) {}
    public function update(Request $request, $id) {}
    public function remove($id) {}
}
